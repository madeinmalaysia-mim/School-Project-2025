Change apiBase in lib/main.dart to your domain and run flutter pub get
