import os, time
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
CORS(app)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///schoolpro.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["UPLOAD_FOLDER"] = "uploads"
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(10), default="user")

class PDFFile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    uploaded_at = db.Column(db.DateTime, server_default=db.func.now())
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))

with app.app_context():
    db.create_all()
    if not User.query.filter_by(username='admin').first():
        admin = User(username='admin', password=generate_password_hash('admin123'), role='admin')
        db.session.add(admin)
    if not User.query.filter_by(username='murid1').first():
        u = User(username='murid1', password=generate_password_hash('murid123'), role='user')
        db.session.add(u)
    db.session.commit()

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json(silent=True) or {}
    username = data.get('username','').strip()
    password = data.get('password','')
    user = User.query.filter_by(username=username).first()
    if user and check_password_hash(user.password, password):
        return jsonify({'id': user.id, 'role': user.role, 'username': user.username})
    return jsonify({'error':'Invalid login'}), 401

@app.route('/files', methods=['GET'])
def list_files():
    role = request.args.get('role','user')
    user_id = request.args.get('user_id', type=int)
    if role == 'admin':
        files = PDFFile.query.order_by(PDFFile.uploaded_at.desc()).all()
    else:
        files = PDFFile.query.filter_by(user_id=user_id).order_by(PDFFile.uploaded_at.desc()).all()
    return jsonify([{'id': f.id, 'title': f.title, 'description': f.description or '', 'filename': f.filename, 'uploaded_at': f.uploaded_at.isoformat() if f.uploaded_at else None, 'user_id': f.user_id} for f in files])

@app.route('/upload', methods=['POST'])
def upload_file():
    user_id = request.form.get('user_id', type=int)
    title = (request.form.get('title') or '').strip()
    description = request.form.get('description','')
    if not user_id or not title:
        return jsonify({'error':'Missing user_id or title'}), 400
    if 'file' not in request.files:
        return jsonify({'error':'No file uploaded'}), 400
    file = request.files['file']
    if not file.filename.lower().endswith('.pdf'):
        return jsonify({'error':'Only PDF allowed'}), 400
    safe_name = secure_filename(file.filename)
    unique_name = f"{int(time.time())}_{safe_name}"
    save_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_name)
    file.save(save_path)
    pdf = PDFFile(filename=unique_name, title=title, description=description, user_id=user_id)
    db.session.add(pdf)
    db.session.commit()
    return jsonify({'message':'File uploaded successfully', 'id': pdf.id})

@app.route('/delete/<int:file_id>', methods=['DELETE'])
def delete_file(file_id):
    pdf = PDFFile.query.get(file_id)
    if not pdf:
        return jsonify({'error':'File not found'}), 404
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], pdf.filename)
    if os.path.exists(file_path):
        os.remove(file_path)
    db.session.delete(pdf)
    db.session.commit()
    return jsonify({'message':'File deleted'})

@app.route('/uploads/<path:filename>')
def serve_upload(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=False)

@app.route('/', methods=['GET'])
def health():
    return jsonify({'status':'ok','message':'SchoolPro Flask API running'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
