SchoolPro Flask Backend (minimal)
- Run: python3 -m venv venv; source venv/bin/activate; pip install -r requirements.txt
- Start: python app.py
- Endpoints: /login (POST JSON), /files (GET), /upload (POST multipart), /delete/<id> (DELETE), /uploads/<filename>
Default users seeded: admin/admin123, murid1/murid123
