import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:file_picker/file_picker.dart';
import 'package:open_file/open_file.dart';

void main() => runApp(const MyApp());

const apiUrlBase = "https://metatrade.space/schoolpro_api"; // change to your domain

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'SchoolPro', home: LoginPage());
  }
}

class LoginPage extends StatefulWidget {
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final userCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  bool loading = false;

  Future<void> login() async {
    setState(() => loading = true);
    final resp = await http.post(Uri.parse("\$apiUrlBase/login.php"),
        body: jsonEncode({"username": userCtrl.text, "password": passCtrl.text}));
    setState(() => loading = false);
    if (resp.statusCode == 200) {
      final data = jsonDecode(resp.body);
      if (data["status"] == "success") {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => HomePage(userId: data["user_id"], role: data["role"])));
        return;
      }
    }
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Login failed')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(children: [
          TextField(controller: userCtrl, decoration: InputDecoration(labelText: 'Username')),
          TextField(controller: passCtrl, decoration: InputDecoration(labelText: 'Password'), obscureText: true),
          SizedBox(height: 20),
          ElevatedButton(onPressed: loading ? null : login, child: loading ? CircularProgressIndicator() : Text('Login'))
        ]),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final int userId;
  final String role;
  HomePage({required this.userId, required this.role});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List files = [];
  bool loading = true;

  Future<void> fetchFiles() async {
    final resp = await http.get(Uri.parse("\$apiUrlBase/list.php?user_id=\${widget.userId}&role=\${widget.role}"));
    if (resp.statusCode == 200) {
      final data = jsonDecode(resp.body);
      setState(() { files = data["files"]; loading = false; });
    }
  }

  Future<void> uploadFile() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
    if (result != null) {
      final file = File(result.files.single.path!);
      final req = http.MultipartRequest('POST', Uri.parse("\$apiUrlBase/upload.php"));
      req.fields['user_id'] = widget.userId.toString();
      req.fields['title'] = result.files.single.name;
      req.files.add(await http.MultipartFile.fromPath('file', file.path));
      final streamed = await req.send();
      final body = await streamed.stream.bytesToString();
      final data = jsonDecode(body);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['message'] ?? 'Upload done')));
      fetchFiles();
    }
  }

  Future<void> deleteFile(String id) async {
    final resp = await http.post(Uri.parse("\$apiUrlBase/delete.php"), body: {'file_id': id, 'role': widget.role});
    final data = jsonDecode(resp.body);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['message'] ?? 'Deleted')));
    fetchFiles();
  }

  @override
  void initState() {
    super.initState();
    fetchFiles();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('SchoolPro - \${widget.role}'), actions: [
        IconButton(icon: Icon(Icons.upload_file), onPressed: uploadFile),
      ]),
      body: loading ? Center(child: CircularProgressIndicator()) : ListView.builder(
        itemCount: files.length,
        itemBuilder: (context, index) {
          final f = files[index];
          return ListTile(
            title: Text(f['title'] ?? f['filename']),
            subtitle: Text(f['uploaded_at'] ?? ''),
            trailing: widget.role == 'admin' ? IconButton(icon: Icon(Icons.delete), onPressed: () => deleteFile(f['id'].toString())) : null,
            onTap: () => OpenFile.open("\$apiUrlBase/uploads/\${f['filename']}"),
          );
        }
      ),
    );
  }
}
