Flutter App (Minimal)
- Change apiUrlBase in lib/main.dart to your server domain (https://metatrade.space/schoolpro_api)
- Run: flutter pub get
- Run app: flutter run
