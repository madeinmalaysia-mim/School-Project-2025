<?php
include "db.php";
header('Content-Type: application/json');

$file_id = isset($_POST['file_id']) ? intval($_POST['file_id']) : 0;
$role = $_POST['role'] ?? 'user';

if ($role !== 'admin') {
    echo json_encode(["status"=>"error","message"=>"Not allowed"]);
    exit;
}

$stmt = $conn->prepare("SELECT filepath FROM files WHERE id=?");
$stmt->bind_param("i", $file_id);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows === 0) {
    echo json_encode(["status"=>"error","message"=>"File not found"]);
    exit;
}
$row = $res->fetch_assoc();
$path = $row['filepath'];
if (file_exists($path)) {
    @unlink($path);
}
$stmt2 = $conn->prepare("DELETE FROM files WHERE id=?");
$stmt2->bind_param("i", $file_id);
$stmt2->execute();
echo json_encode(["status"=>"success","message"=>"File deleted"]);
?>