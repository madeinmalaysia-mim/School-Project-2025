<?php
include "db.php";
header('Content-Type: application/json');

$user_id = $_POST['user_id'] ?? null;
$title = $_POST['title'] ?? 'Untitled';
$description = $_POST['description'] ?? '';

if (!$user_id) {
    echo json_encode(["status"=>"error","message"=>"Missing user_id"]);
    exit;
}

if (!isset($_FILES['file'])) {
    echo json_encode(["status"=>"error","message"=>"No file uploaded"]);
    exit;
}

$targetDir = "uploads/";
if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

$filename = basename($_FILES["file"]["name"]);
$unique = time() . '_' . preg_replace('/[^A-Za-z0-9._-]/', '_', $filename);
$targetFile = $targetDir . $unique;

if (move_uploaded_file($_FILES['file']['tmp_name'], $targetFile)) {
    $stmt = $conn->prepare("INSERT INTO files (user_id, filename, filepath, uploaded_at) VALUES (?,?,?,NOW())");
    $stmt->bind_param("iss", $user_id, $filename, $targetFile);
    $stmt->execute();
    echo json_encode(["status"=>"success","message"=>"File uploaded","id"=>$stmt->insert_id]);
} else {
    echo json_encode(["status"=>"error","message"=>"Upload failed"]);
}
?>