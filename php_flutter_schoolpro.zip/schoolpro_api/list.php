<?php
include "db.php";
header('Content-Type: application/json');

$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
$role = $_GET['role'] ?? 'user';

if ($role === 'admin') {
    $sql = "SELECT files.*, users.username FROM files LEFT JOIN users ON files.user_id = users.id ORDER BY uploaded_at DESC";
    $result = $conn->query($sql);
} else {
    $stmt = $conn->prepare("SELECT * FROM files WHERE user_id=? ORDER BY uploaded_at DESC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
}

$files = [];
while ($row = $result->fetch_assoc()) {
    $files[] = $row;
}

echo json_encode(["status"=>"success","files"=>$files]);
?>