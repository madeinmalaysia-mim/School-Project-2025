SchoolPro PHP API
=================

Files:
- db.php : DB connection
- login.php : POST JSON {username,password}
- upload.php : POST multipart form (user_id,title,description,file)
- list.php : GET ?user_id=&role=
- delete.php : POST (file_id, role) admin only

Setup:
1. Create database and run sql_init.sql via phpMyAdmin or mysql client.
2. Place files in public_html/schoolpro_api/
3. Ensure uploads/ is writable by web server.
4. API URL example: https://metatrade.space/schoolpro_api/list.php?user_id=2&role=user
