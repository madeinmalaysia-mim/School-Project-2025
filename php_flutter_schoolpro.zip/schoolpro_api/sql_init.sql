-- SQL to create database and tables
CREATE DATABASE IF NOT EXISTS schoolpro;
USE schoolpro;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE,
  password VARCHAR(255),
  role ENUM('admin','user') DEFAULT 'user'
);

CREATE TABLE IF NOT EXISTS files (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  filename VARCHAR(255),
  filepath VARCHAR(255),
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Insert default admin and sample user (passwords are md5 for this example: admin123, murid123)
INSERT INTO users (username, password, role) VALUES ('admin', MD5('admin123'), 'admin') ON DUPLICATE KEY UPDATE username=username;
INSERT INTO users (username, password, role) VALUES ('murid1', MD5('murid123'), 'user') ON DUPLICATE KEY UPDATE username=username;
